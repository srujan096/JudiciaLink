import { LawyerDashboard } from "@/components/lawyer-dashboard"

export default function LawyerPage() {
  return <LawyerDashboard />
}

