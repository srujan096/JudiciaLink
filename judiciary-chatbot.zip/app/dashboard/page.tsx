import { UserDashboard } from "@/components/user-dashboard"

export default function Dashboard() {
  return <UserDashboard />
}

